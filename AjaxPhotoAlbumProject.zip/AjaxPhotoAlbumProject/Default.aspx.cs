using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Tirex;


public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            pAdd.Visible = false;
        }
    }

    protected void lbAdd_Click(object sender, EventArgs e)
    {
        if (pAdd.Visible == false)
        {
            pAdd.Visible = true;
        }
        else
        {

            int len1 = 0;
            byte[] imageSmall = null;
            byte[] imageLarge = null;

            //try
            //{
                len1 = File1.PostedFile.ContentLength;
                imageSmall = new byte[len1];
                imageLarge = new byte[len1];
                File1.PostedFile.InputStream.Read(imageLarge, 0, len1);
                imageSmall = ImageClass.ResizeImage(250, imageLarge);
                imageLarge = ImageClass.ResizeImage(250, imageLarge);

                //ImageClass.AddImage(imageSmall, imageLarge);
            //}
            //catch { }

            PhotoAlbumControl1.PopulateThumbnails();
            pAdd.Visible = false;
        }
    }
}
