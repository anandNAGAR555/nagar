using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Tirex;


public partial class ImagePage : System.Web.UI.Page
{
    #region Events Handlers
    private void Page_Load(object sender, System.EventArgs e)
    {
        string sSQL = "";

        SqlDataReader drData = null;
        SqlCommand cmd = null;
        SqlConnection cnn = new SqlConnection(SqlHelper.connectionString());
        cnn.Open();

        string id = Request.Params["id"].ToString();
        string s = Request.Params["s"].ToString();
        
        if (s == "s")
        {
            sSQL = "SELECT ImageSmall FROM Images WHERE ImageId=" + id.ToString();
        }
        else
        {
            sSQL = "SELECT ImageLarge FROM Images WHERE ImageId=" + id.ToString();
        }

        //try
        //{
        using (cmd = new SqlCommand())
        {
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = sSQL;
            cmd.Connection = cnn;
            drData = cmd.ExecuteReader();
            if (drData.Read())
            {
                if (s == "s")
                {
                    Response.BinaryWrite((byte[])drData["ImageSmall"]);
                }
                else
                {
                    Response.BinaryWrite((byte[])drData["ImageLarge"]);
                }
                
            }
            cnn.Close();
        }
        //}
        //catch { }
    }
    #endregion

    #region Web Form Designer generated code
    override protected void OnInit(EventArgs e)
    {
        //
        // CODEGEN: This call is required by the ASP.NET Web Form Designer.
        //
        InitializeComponent();
        base.OnInit(e);
    }

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        this.Load += new System.EventHandler(this.Page_Load);

    }
    #endregion
}

