using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Tirex;

public partial class GetSelectedImage : System.Web.UI.Page
{
    DataSet ds = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {

        Response.Clear();
        Response.ContentType = "text/xml";

        int id = 0;

        if (Request.Params["id"] != null)
        {
            id = Int32.Parse(Request.Params["id"].ToString());
            
        }
        else
        {
            if (Session["ImageId"] != null)
            {
                id = Int32.Parse(Session["ImageId"].ToString());
            }

            id = ImageClass.GetImageId(id);
            Session["ImageId"] = id.ToString();
        }
        
        Session["SelectedImageId"] = id.ToString();

        Response.Write("<Root>");
        Response.Write("<ImageId>");
        Response.Write(id);
        Response.Write("</ImageId>");
        Response.Write("</Root>");

    }
}
